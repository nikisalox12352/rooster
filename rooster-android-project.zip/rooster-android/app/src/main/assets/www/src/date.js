const pad = (value) => String(value).padStart(2, '0');
export const toISO = (date) => `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
export const fromISO = (value) => {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(year, month - 1, day, 12, 0, 0, 0);
};
export const addDays = (date, count) => {
  const value = new Date(date);
  value.setDate(value.getDate() + count);
  return value;
};
export const mondayOf = (date) => {
  const value = new Date(date);
  value.setDate(value.getDate() - ((value.getDay() + 6) % 7));
  value.setHours(12, 0, 0, 0);
  return value;
};
export const isoWeek = (date) => {
  const value = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  value.setUTCDate(value.getUTCDate() + 4 - (value.getUTCDay() || 7));
  const yearStart = new Date(Date.UTC(value.getUTCFullYear(), 0, 1));
  return Math.ceil((((value - yearStart) / 86400000) + 1) / 7);
};
export const monthName = (date) => new Intl.DateTimeFormat('en-US', { month: 'long' }).format(date);
export const dayShort = (date) => new Intl.DateTimeFormat('nl-NL', { weekday: 'short' }).format(date).replace('.', '');
export const formatDateLong = (iso) => new Intl.DateTimeFormat('nl-NL', { weekday: 'long', day: 'numeric', month: 'long' }).format(fromISO(iso));
export const timeToMinutes = (value) => { const [hour, minute] = value.split(':').map(Number); return hour * 60 + minute; };
export const uid = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
