const subjects = [
  { id:'nl', name:'Nederlandse taal', short:'NL', icon:'Aa', color:'#a8d5ff', description:'Taal en communicatie' },
  { id:'act', name:'Act', short:'Act', icon:'◉', color:'#b2d7ff' },
  { id:'wi', name:'wiskunde', short:'wi', icon:'¹²₃', color:'#9bcfff', description:'Rekenen en wiskunde' },
  { id:'pie', name:'produceren, installeren en energie', short:'PIE', icon:'⚙', color:'#a4d3ff' },
  { id:'ond', name:'ondernemen', short:'ond', icon:'▣', color:'#a8d5ff' },
  { id:'rek', name:'rekenen (digitaal)', short:'rek', icon:'7+', color:'#a8d5ff' },
  { id:'en', name:'Engelse taal', short:'EN', icon:'EN', color:'#a8d5ff' },
  { id:'nsk', name:'natuur- en scheikunde I', short:'nsk', icon:'⚗', color:'#a8d5ff' },
  { id:'hw', name:'huiswerkbegeleiding', short:'hw', icon:'H', color:'#a8d5ff' },
  { id:'sok', name:'sok', short:'sok', icon:'◌', color:'#a8d5ff' },
  { id:'toets', name:'Toets', short:'Toets', icon:'✓', color:'#f0a15a' },
];
const lesson = (id, date, start, end, title, subjectId, room = '', type = '', extra = {}) => ({
  id, date, start, end, title, subjectId, room, teacher:'', group:'', color:'#1c344c', info:'', notes:'', type, ...extra,
});
export function createSeedData() {
  return {
    subjects,
    lessons: [
      lesson('l-171','2026-11-17','08:00','09:10','Engelse taal','en','h115'),
      lesson('l-172','2026-11-17','09:20','10:30','Nederlandse taal','nl','h114'),
      lesson('l-173','2026-11-17','10:40','11:50','natuur- en scheikunde I','nsk','h301'),
      lesson('l-181','2026-11-18','08:00','10:00','Toets','toets','','Toets 8:00'),
      lesson('l-182','2026-11-18','08:00','09:10','huiswerkbegeleiding','hw','h104'),
      lesson('l-183','2026-11-18','09:20','10:30','natuur- en scheikunde I','nsk','h301'),
      lesson('l-184','2026-11-18','10:40','11:50','produceren, installeren en energie','pie','h001b'),
      lesson('l-185','2026-11-18','11:50','13:00','produceren, installeren en energie','pie','h001b'),
      lesson('l-191','2026-11-19','11:50','13:00','produceren, installeren en energie','pie','h001b'),
      lesson('l-192','2026-11-19','13:20','14:30','sok','sok'),
      lesson('l-193','2026-11-19','14:30','15:40','sok','sok'),
      lesson('l-201','2026-11-20','08:00','09:10','Nederlandse taal','nl','h114'),
      lesson('l-202','2026-11-20','09:10','10:20','Act','act','h107'),
      lesson('l-203','2026-11-20','10:40','11:50','wiskunde','wi','h116','', { group:'hsg', info:'wi' }),
      lesson('l-204','2026-11-20','11:50','13:00','produceren, installeren en energie','pie','h001b'),
      lesson('l-205','2026-11-20','13:20','14:30','ondernemen','ond','h006'),
      lesson('l-206','2026-11-20','14:30','15:40','ondernemen','ond','h006'),
      lesson('l-207','2026-11-20','17:00','18:00','rekenen (digitaal)','rek'),
    ],
    homework: [
      { id:'hw-en-1', subjectId:'en', date:'2026-11-17', title:'Huiswerk', description:'Neem allebei je taaldorp boekjes mee!!!', done:false },
    ],
    tasks: [{ id:'task-20', date:'2026-11-20', title:'Dagtaak', done:false }],
    notices: [{ id:'notice-18', date:'2026-11-18', text:'ON Melden om 07:30 bij de balie', tone:'orange' }],
    templates: [],
    messages: [{ id:'msg-1', title:'Mededeling', body:'Je hebt een nieuw bericht.', date:'2026-11-20', unread:true }],
    daysOff: [],
  };
}
