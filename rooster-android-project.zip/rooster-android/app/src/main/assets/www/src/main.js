import { createSeedData } from './seed.js';
import { loadData, saveData } from './storage.js';
import { addDays, dayShort, formatDateLong, fromISO, isoWeek, mondayOf, monthName, timeToMinutes, toISO, uid } from './date.js';

const root = document.getElementById('root');
const TODAY = toISO(new Date());
const START_HOUR = 6;
const END_HOUR = 20;
const HOUR_HEIGHT = 117;

let data = createSeedData();
let selectedDate = TODAY;
let activeTab = 'Rooster';
let taskExpanded = false;
let noticeExpanded = false;
let controlsVisible = false;
let compactHeader = false;
let detailLessonId = null;
let subjectViewId = null;
let materialsLessonId = null;
let sidebarOpen = false;
let adminOpen = false;
let adminTab = 'overview';
let editor = null;
let messageDetailId = null;
let undoStack = [];
let monthTapState = { count: 0, last: 0 };
let loaded = false;

const esc = (value = '') => String(value).replace(/[&<>"']/g, (char) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[char]));
const icon = (name, size = 22) => {
  const paths = {
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18M8 14h2M13 14h2"/>',
    today: '<path d="M5 12h14M13 6l6 6-6 6"/><path d="M4 4v16"/>',
    left: '<path d="m15 18-6-6 6-6"/>',
    right: '<path d="m9 18 6-6-6-6"/>',
    down: '<path d="m6 9 6 6 6-6"/>',
    up: '<path d="m6 15 6-6 6 6"/>',
    close: '<path d="m18 6-12 12M6 6l12 12"/>',
    home: '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/>',
    book: '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v18H6.5A2.5 2.5 0 0 1 4 17.5z"/><path d="M4 17.5A2.5 2.5 0 0 1 6.5 15H20M8 6h8"/>',
    back: '<path d="m14 18-6-6 6-6M8 12h13"/>',
    edit: '<path d="m15 5 4 4M4 20l4-.8L19 8a2.1 2.1 0 0 0-3-3L5 16z"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 14h10l1-14M9 7V4h6v3"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    save: '<path d="M5 3h12l3 3v15H4V4a1 1 0 0 1 1-1z"/><path d="M8 3v6h8V3M8 21v-7h8v7"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.8-.6a8 8 0 0 1-1.6.9l-.3 1.9h-2.8l-.3-1.9a8 8 0 0 1-1.6-.9l-1.8.6-1.4-2.4 1.4-1.1a7 7 0 0 1 0-1.9L5.9 12l1.4-2.4 1.8.6a8 8 0 0 1 1.6-.9L11 7.4h2.8l.3 1.9a8 8 0 0 1 1.6.9l1.8-.6 1.4 2.4-1.4 1.1a7 7 0 0 1-.1 1.9z"/>',
    bell: '<path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
    upload: '<path d="M12 16V4m-5 5 5-5 5 5M4 16v4h16v-4"/>',
    download: '<path d="M12 4v12m-5-5 5 5 5-5M4 20h16"/>',
    rotate: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
    shield: '<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11z"/><path d="m9 12 2 2 4-4"/>',
    folder: '<path d="M3 6a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    graduation: '<path d="m2 9 10-5 10 5-10 5zM6 11v5c4 3 8 3 12 0v-5M22 9v6"/>',
    message: '<path d="M21 11.5a8.5 8.5 0 0 1-12.4 7.6L3 21l1.9-5.1A8.5 8.5 0 1 1 21 11.5z"/>',
    more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
  };
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.more}</svg>`;
};

function subjectById(id) { return data.subjects.find((item) => item.id === id); }
function lessonById(id) { return data.lessons.find((item) => item.id === id); }
function currentDate() { return fromISO(selectedDate); }
function taskCounts() {
  const tasks = data.tasks.filter((item) => item.date === selectedDate);
  const homework = data.homework.filter((item) => item.date === selectedDate);
  return { done: tasks.filter((item) => item.done).length + homework.filter((item) => item.done).length, total: tasks.length + homework.length, tasks, homework };
}
function commit(updater) {
  undoStack.push(JSON.parse(JSON.stringify(data)));
  if (undoStack.length > 20) undoStack.shift();
  data = updater(data);
  render();
  saveData(data).catch((error) => console.error('Opslaan mislukt', error));
}
function undo() {
  if (!undoStack.length) return;
  data = undoStack.pop();
  render();
  saveData(data).catch((error) => console.error(error));
}
function setDate(value) {
  if (!value) return;
  selectedDate = value;
  taskExpanded = false;
  noticeExpanded = false;
  controlsVisible = true;
  detailLessonId = null;
  render();
}
function monthTitle() { return monthName(currentDate()); }
function handleMonthTap() {
  const now = Date.now();
  const count = now - monthTapState.last <= 3000 ? monthTapState.count + 1 : 1;
  monthTapState = { count, last: now };
  if (count >= 5) { monthTapState = { count: 0, last: 0 }; adminOpen = true; adminTab = 'overview'; render(); }
}

function renderWeekStrip() {
  const start = mondayOf(currentDate());
  const days = Array.from({ length: 5 }, (_, index) => addDays(start, index));
  return `<div class="week-strip">
    <div class="week-cell week-number"><span>WK</span><strong>${isoWeek(currentDate())}</strong></div>
    ${days.map((date) => {
      const key = toISO(date);
      const chosen = key === selectedDate;
      const today = key === TODAY;
      const hasLessons = data.lessons.some((item) => item.date === key);
      const hasNotice = data.notices.some((item) => item.date === key);
      const hasHomework = data.homework.some((item) => item.date === key);
      return `<button class="week-cell day-cell ${chosen ? 'chosen' : ''} ${today ? 'today' : ''}" data-action="select-date" data-date="${key}">
        <span class="weekday-name">${esc(dayShort(date).slice(0, 1).toUpperCase())}</span><strong>${date.getDate()}</strong><span class="dots">${hasLessons ? '<i class="dot blue"></i>' : ''}${hasNotice ? '<i class="dot red"></i>' : ''}</span>
      </button>`;
    }).join('')}
  </div>`;
}

function getLessonLanes(lessons) {
  const sorted = [...lessons].sort((a, b) => timeToMinutes(a.start) - timeToMinutes(b.start));
  const output = new Map();
  let cluster = [];
  let clusterEnd = -1;
  const flush = () => {
    if (!cluster.length) return;
    const laneEnds = [];
    const assignments = [];
    for (const lesson of cluster) {
      const start = timeToMinutes(lesson.start);
      const end = timeToMinutes(lesson.end);
      let lane = laneEnds.findIndex((value) => value <= start);
      if (lane === -1) lane = laneEnds.length;
      laneEnds[lane] = end;
      assignments.push({ id: lesson.id, lane });
    }
    const lanes = Math.max(1, laneEnds.length);
    assignments.forEach((item) => output.set(item.id, { lane: item.lane, lanes }));
    cluster = []; clusterEnd = -1;
  };
  for (const lesson of sorted) {
    const start = timeToMinutes(lesson.start);
    const end = timeToMinutes(lesson.end);
    if (cluster.length && start >= clusterEnd) flush();
    cluster.push(lesson);
    clusterEnd = Math.max(clusterEnd, end);
  }
  flush();
  return output;
}

function renderTimeline() {
  const lessons = data.lessons.filter((item) => item.date === selectedDate);
  if (data.daysOff.includes(selectedDate)) return `<div class="day-off">${icon('calendar', 28)}<strong>Geen lessen</strong><span>Deze dag is ingesteld als lesvrije dag.</span></div>`;
  const laneMap = getLessonLanes(lessons);
  const height = (END_HOUR - START_HOUR) * HOUR_HEIGHT;
  const labels = Array.from({ length: END_HOUR - START_HOUR }, (_, index) => START_HOUR + index + 1);
  const hourRows = labels.map((hour) => `<div class="hour-row" style="top:${(hour - START_HOUR) * HOUR_HEIGHT + 12}px">${hour >= 8 ? `<span>${String(hour).padStart(2, '0')}:00</span>` : ''}<i></i></div>`).join('');
  const cards = lessons.map((lesson) => {
    const lane = laneMap.get(lesson.id) || { lane: 0, lanes: 1 };
    const top = (timeToMinutes(lesson.start) - START_HOUR * 60) * HOUR_HEIGHT / 60 - 2;
    const duration = timeToMinutes(lesson.end) - timeToMinutes(lesson.start);
    const cardHeight = Math.max(78, duration * HOUR_HEIGHT / 60 - 7);
    const subject = subjectById(lesson.subjectId);
    const displayTitle = lesson.subjectId === 'toets' ? '' : lesson.title;
    return `<button class="lesson-card" data-action="open-lesson" data-id="${esc(lesson.id)}" style="top:${top}px;height:${cardHeight}px;left:calc(${lane.lane} * (100% / ${lane.lanes}));width:calc(100% / ${lane.lanes} - ${lane.lanes > 1 ? 7 : 0}px);background:${esc(lesson.color || '#1c344c')};--lesson-accent:${esc(subject?.color || '#a8d5ff')}">
      ${displayTitle ? `<span class="lesson-title">${esc(displayTitle)}</span>` : ''}
      ${lesson.room ? `<span class="lesson-room">${esc(lesson.room)}</span>` : ''}
      ${lesson.type ? `<span class="lesson-type">${esc(lesson.type)}</span>` : `<span class="lesson-time">${esc(lesson.start)}</span>`}
      ${lesson.notes ? '<span class="lesson-indicator">•</span>' : ''}
    </button>`;
  }).join('');
  return `<div class="timeline" style="height:${height}px"><div class="timeline-axis">${hourRows}<span class="earlier-label">Eerder</span><span class="later-label">Later</span></div><div class="timeline-card-area">${cards}</div></div>`;
}

function renderDayControls() {
  const counts = taskCounts();
  const notices = data.notices.filter((item) => item.date === selectedDate);
  return `<section class="day-controls ${controlsVisible ? '' : 'hidden'}">
    <button class="task-summary" data-action="toggle-tasks"><span>${counts.done}/${counts.total} taak</span><span class="task-status ${counts.total > counts.done ? 'red-dot' : ''}"></span>${icon(taskExpanded ? 'up' : 'down', 18)}</button>
    ${taskExpanded ? `<div class="expanded-tasks">
      ${counts.total === 0 ? '<div class="muted-empty">Geen taken voor deze dag</div>' : ''}
      ${counts.tasks.map((item) => `<label class="task-row"><input type="checkbox" data-action="toggle-task" data-kind="task" data-id="${esc(item.id)}" ${item.done ? 'checked' : ''}><span class="${item.done ? 'done' : ''}">${esc(item.title)}</span></label>`).join('')}
      ${counts.homework.map((item) => `<label class="task-row"><input type="checkbox" data-action="toggle-task" data-kind="homework" data-id="${esc(item.id)}" ${item.done ? 'checked' : ''}><span class="${item.done ? 'done' : ''}">${esc(item.title)}: ${esc(item.description)}</span></label>`).join('')}
    </div>` : ''}
    ${notices.map((notice) => `<button class="notice-banner ${esc(notice.tone)} ${noticeExpanded ? 'expanded' : ''}" data-action="toggle-notice"><span>${esc(notice.text)}</span>${icon(noticeExpanded ? 'up' : 'down', 18)}${noticeExpanded ? `<small>Mededeling voor ${esc(formatDateLong(notice.date))}</small>` : ''}</button>`).join('')}
  </section>`;
}

function renderRooster() {
  if (subjectViewId) return renderSubjectPage();
  if (materialsLessonId) return renderMaterialsPage();
  const month = monthTitle();
  return `<main class="rooster-page">
    <header class="rooster-head ${compactHeader ? 'compact' : ''}">
      <div class="top-toolbar">
        <button class="icon-button menu-trigger" aria-label="Menu" data-action="open-menu">${icon('menu')}</button>
        <button class="avatar" aria-label="Profiel" data-action="open-menu">M</button>
        <button class="month-inline" data-action="month-tap">${esc(month)}</button>
        <div class="toolbar-actions">
          <button class="icon-button" aria-label="Kies datum" data-action="date-picker">${icon('calendar')}</button>
          <button class="icon-button" aria-label="Vandaag" data-action="today">${icon('today')}</button>
          <button class="icon-button" aria-label="Vorige dag" data-action="prev-day">${icon('left')}</button>
          <button class="icon-button" aria-label="Volgende dag" data-action="next-day">${icon('right')}</button>
        </div>
      </div>
      <div class="month-hero"><button data-action="month-tap">${esc(month)}</button></div>
      <input class="native-date" id="top-date-picker" type="date" value="${selectedDate}" />
      ${renderWeekStrip()}
    </header>
    ${renderDayControls()}
    <section class="timeline-wrap" id="timeline-wrap">${renderTimeline()}</section>
  </main>`;
}

function renderSubjectPage() {
  const subject = subjectById(subjectViewId);
  if (!subject) { subjectViewId = null; return renderRooster(); }
  const homework = data.homework.filter((item) => item.subjectId === subject.id);
  const lessons = data.lessons.filter((item) => item.subjectId === subject.id).sort((a, b) => a.date.localeCompare(b.date) || a.start.localeCompare(b.start));
  return `<main class="subpage">
    <header class="subpage-header"><button class="icon-button back-button" data-action="back-subpage">${icon('back')}</button><span class="icon-button" aria-hidden="true">${icon('book')}</span></header>
    <div class="subpage-content"><h1>${esc(subject.name)}</h1>
      ${homework.map((item) => `<section class="homework-card">
        ${item.description ? `<p class="announcement-text">${esc(item.description)}</p>` : ''}
        <div class="homework-line"><span class="homework-icon">${icon('graduation', 24)}</span><strong>${esc(item.title)}</strong><span class="homework-check-label">Afvinken</span><input type="checkbox" aria-label="Huiswerk afvinken" data-action="toggle-task" data-kind="homework" data-id="${esc(item.id)}" ${item.done ? 'checked' : ''}></div>
        <div class="homework-date">${icon('calendar', 22)}<span>${esc(formatDateLong(item.date))}</span></div>
      </section>`).join('')}
      ${homework.length ? '' : '<div class="empty-section">Geen huiswerk beschikbaar.</div>'}
      <h2 class="small-section-title">Lessen</h2><div class="subject-lessons">${lessons.slice(0, 10).map((lesson) => `<button class="subject-lesson-row" data-action="open-lesson" data-id="${esc(lesson.id)}"><span>${esc(formatDateLong(lesson.date))}</span><strong>${esc(lesson.start)} · ${esc(lesson.room || '—')}</strong>${icon('right', 18)}</button>`).join('') || '<div class="empty-section">Geen lessen gevonden.</div>'}</div>
    </div>
  </main>`;
}

function renderMaterialsPage() {
  const lesson = lessonById(materialsLessonId);
  const subject = lesson ? subjectById(lesson.subjectId) : null;
  return `<main class="subpage"><header class="subpage-header"><button class="icon-button back-button" data-action="back-subpage">${icon('back')}</button>${icon('book')}</header><div class="subpage-content"><h1>Studiemateriaal</h1><p class="muted-copy">${esc(lesson?.title || subject?.name || 'Les')}${lesson ? ` · ${esc(lesson.start)} - ${esc(lesson.end)}` : ''}</p><div class="materials-empty">${icon('book', 38)}<strong>Geen studiemateriaal toegevoegd</strong><span>Materialen voor deze les verschijnen hier wanneer ze beschikbaar zijn.</span></div></div></main>`;
}

function renderOtherTab() {
  if (activeTab === 'Start') {
    const lessons = data.lessons.filter((item) => item.date === selectedDate).sort((a, b) => a.start.localeCompare(b.start));
    return `<main class="other-page"><h1>Start</h1><p class="muted-copy">${esc(formatDateLong(selectedDate))}</p><div class="section-caption">Vandaag</div>${lessons.map((lesson) => `<div class="mini-lesson"><span>${esc(lesson.start)}</span><strong>${esc(lesson.title)}</strong><small>${esc(lesson.room)}</small></div>`).join('') || '<div class="empty-section">Geen lessen op deze dag.</div>'}</main>`;
  }
  if (activeTab === 'Studiewijzer') {
    return `<main class="other-page"><h1>Studiewijzer</h1><p class="muted-copy">Vakken en bijbehorende informatie</p><div class="subject-list">${data.subjects.map((subject) => `<button class="subject-list-row" data-action="open-subject" data-id="${esc(subject.id)}"><span class="subject-icon small">${esc(subject.icon)}</span><span><strong>${esc(subject.name)}</strong><small>${esc(subject.short)}</small></span>${icon('right', 19)}</button>`).join('')}</div></main>`;
  }
  if (activeTab === 'Cijfers') return `<main class="other-page"><h1>Cijfers</h1><p class="muted-copy">Overzicht van resultaten</p><div class="materials-empty">${icon('book', 38)}<strong>Nog geen cijfers</strong><span>Er zijn op dit moment geen resultaten beschikbaar.</span></div></main>`;
  return `<main class="other-page"><h1>Berichten</h1><p class="muted-copy">Berichten en mededelingen</p><div class="message-list">${data.messages.map((message) => `<button class="message-row" data-action="open-message" data-id="${esc(message.id)}"><span class="message-icon">${icon('mail', 20)}</span><span><strong>${esc(message.title)}</strong><small>${esc(message.body)}</small><small>${esc(formatDateLong(message.date))}</small></span>${message.unread ? '<i></i>' : ''}</button>`).join('') || '<div class="empty-section">Geen berichten.</div>'}</div></main>`;
}

function renderBottomNav() {
  const items = [
    ['Start', icon('home', 22)], ['Rooster', '<span class="nav-letter">R</span>'], ['Studiewijzer', '<span class="nav-letter home-letter">H</span>'], ['Cijfers', '<span class="nav-letter number-letter">7+</span>'], ['Berichten', icon('mail', 22)],
  ];
  const unread = data.messages.filter((item) => item.unread).length;
  return `<nav class="bottom-nav">${items.map(([tab, image]) => `<button class="nav-item ${activeTab === tab ? 'active' : ''}" data-action="tab" data-tab="${tab}"><span class="nav-icon">${image}${tab === 'Berichten' && unread ? `<b class="unread-badge">${unread}</b>` : ''}</span><span>${tab}</span></button>`).join('')}</nav>`;
}

function renderLessonSheet() {
  const lesson = lessonById(detailLessonId);
  if (!lesson) return '';
  const subject = subjectById(lesson.subjectId);
  const duration = Math.max(0, timeToMinutes(lesson.end) - timeToMinutes(lesson.start));
  return `<div class="sheet-backdrop" data-action="close-sheet"><section class="lesson-sheet" data-stop-click="true"><div class="sheet-handle"></div>
    <div class="sheet-title-row"><div class="subject-icon">${esc(subject?.icon || '▣')}</div><button class="sheet-heading" data-action="sheet-open-subject"><strong>${esc(lesson.title)}</strong><small>${esc(subject?.short || '')}</small></button><button class="close-button" aria-label="Sluiten" data-action="close-sheet">${icon('close')}</button></div>
    ${lesson.info ? `<p class="lesson-info">${esc(lesson.info)}</p>` : ''}${lesson.group ? `<span class="detail-chip">${esc(lesson.group)}</span>` : ''}
    <div class="lesson-meta-grid"><div class="meta-card"><span>Tijd <b>${duration} min</b></span><strong>${esc(lesson.start)} - ${esc(lesson.end)}</strong></div><div class="meta-card"><span>Locatie</span><strong>${esc(lesson.room || '—')}</strong></div>${lesson.teacher ? `<div class="meta-card"><span>Docent</span><strong>${esc(lesson.teacher)}</strong></div>` : ''}</div>
    ${lesson.notes ? `<div class="detail-notes">${esc(lesson.notes)}</div>` : ''}
    <button class="materials-link" data-action="open-materials">${icon('book')}<span>Studiemateriaal</span>${icon('right')}</button>
  </section></div>`;
}

function renderSidebar() {
  if (!sidebarOpen) return '';
  return `<div class="drawer-backdrop" data-action="close-menu"><aside class="side-drawer" data-stop-click="true"><div class="drawer-head"><span class="avatar large">M</span><strong>Mijn rooster</strong><button class="icon-button" data-action="close-menu">${icon('close')}</button></div><button class="drawer-row" data-action="backup-export">${icon('download',20)} Back-up opslaan</button><button class="drawer-row" data-action="tab" data-tab="Start">${icon('home',20)} Start</button><p class="drawer-foot">Rooster · versie 1.0</p></aside></div>`;
}

function renderMessageDetail() {
  const message = data.messages.find((item) => item.id === messageDetailId);
  if (!message) return '';
  return `<div class="sheet-backdrop" data-action="close-message"><section class="lesson-sheet" data-stop-click="true"><div class="sheet-handle"></div><div class="sheet-title-row"><div class="subject-icon">${icon('mail',22)}</div><div class="sheet-heading"><strong>${esc(message.title)}</strong><small>${esc(formatDateLong(message.date))}</small></div><button class="close-button" data-action="close-message">${icon('close')}</button></div><p class="lesson-info">${esc(message.body)}</p></section></div>`;
}

function renderApp() {
  let content = activeTab === 'Rooster' ? renderRooster() : renderOtherTab();
  root.innerHTML = `<div class="app-frame"><div class="safe-top"></div>${content}${renderBottomNav()}<div class="home-indicator" aria-hidden="true"><i></i></div>${renderLessonSheet()}${renderMessageDetail()}${renderSidebar()}${adminOpen ? renderAdmin() : ''}</div>`;
  attachTimelineScroll();
}
function render() { renderApp(); }
function attachTimelineScroll() {
  const timeline = document.getElementById('timeline-wrap');
  if (!timeline) return;
  timeline.addEventListener('scroll', () => {
    const header = root.querySelector('.rooster-head');
    const compact = timeline.scrollTop > 35;
    if (header) header.classList.toggle('compact', compact);
    compactHeader = compact;
    if (compact && !controlsVisible) { controlsVisible = true; root.querySelector('.day-controls')?.classList.remove('hidden'); }
  }, { passive: true });
}

const adminTabs = [
  ['overview', 'Overzicht'], ['lessons', 'Lessen'], ['subjects', 'Vakken'],
  ['homework', 'Huiswerk'], ['notices', 'Meldingen'], ['days', 'Dagen'],
];
function renderAdmin() {
  return `<div class="admin-overlay"><section class="admin-window">
    <header class="admin-header"><div><span class="admin-kicker">${icon('settings',13)} Beheer</span><h2>Rooster beheren</h2></div><button class="close-button" data-action="close-admin">${icon('close')}</button></header>
    <div class="admin-tabs">${adminTabs.map(([id, label]) => `<button class="${adminTab === id ? 'selected' : ''}" data-action="admin-tab" data-tab="${id}">${label}</button>`).join('')}</div>
    <div class="admin-content">${renderAdminContent()}</div>
    <footer class="admin-footer"><span>${icon('shield',14)} Lokale opslag actief</span><button data-action="close-admin">Sluiten</button></footer>
  </section>${editor ? renderEditor() : ''}</div>`;
}
function renderAdminContent() {
  if (adminTab === 'overview') {
    const counts = [data.lessons.length, data.subjects.length, data.homework.length, data.notices.length];
    return `<div class="admin-stat-grid">${[['Lessen', counts[0]], ['Vakken', counts[1]], ['Opdrachten', counts[2]], ['Meldingen', counts[3]]].map(([label, value]) => `<div><strong>${value}</strong><span>${label}</span></div>`).join('')}</div>
      <section class="admin-card"><h3>Geselecteerde dag</h3><label class="field-label">Datum<input type="date" value="${selectedDate}" data-action="admin-selected-date"></label><p class="admin-muted">${data.lessons.filter((item) => item.date === selectedDate).length} lessen op deze datum</p><button class="primary-button" data-action="new-lesson">${icon('plus',16)} Les toevoegen</button></section>
      <section class="admin-card"><h3>Gegevens en herstel</h3><div class="button-stack"><button class="secondary-button" data-action="backup-export">${icon('download')} Back-up downloaden</button><label class="secondary-button file-button">${icon('upload')} Back-up herstellen<input type="file" accept="application/json,.json" data-action="backup-import"></label><button class="secondary-button" data-action="undo" ${undoStack.length ? '' : 'disabled'}>${icon('rotate')} Laatste actie ongedaan maken</button></div><p class="admin-muted">Wijzigingen worden automatisch lokaal opgeslagen in deze browser.</p></section>`;
  }
  if (adminTab === 'lessons') {
    const sorted = [...data.lessons].sort((a, b) => a.date.localeCompare(b.date) || a.start.localeCompare(b.start));
    return `<div class="admin-section-head"><div><h3>Alle lessen</h3><span>${data.lessons.length} items</span></div><button class="primary-button compact-button" data-action="new-lesson">${icon('plus',15)} Toevoegen</button></div>
      <div class="admin-list">${sorted.map((lesson) => {
        const subject = subjectById(lesson.subjectId);
        return `<article class="admin-list-row"><span class="list-color" style="background:${esc(subject?.color || '#a8d5ff')}"></span><div class="admin-list-main"><strong>${esc(lesson.title)}</strong><span>${esc(lesson.date)} · ${esc(lesson.start)}–${esc(lesson.end)} · ${esc(lesson.room || 'geen lokaal')}${lesson.seriesId ? ' · herhaling' : ''}</span></div><div class="row-actions"><button title="Dupliceren" data-action="duplicate-lesson" data-id="${esc(lesson.id)}">${icon('copy',16)}</button><button title="Bewerken" data-action="edit-lesson" data-id="${esc(lesson.id)}">${icon('edit',16)}</button><button title="Verwijderen" data-action="delete-lesson" data-id="${esc(lesson.id)}">${icon('trash',16)}</button></div></article>`;
      }).join('') || '<div class="admin-empty">Nog geen lessen.</div>'}</div>`;
  }
  if (adminTab === 'subjects') {
    return `<div class="admin-section-head"><div><h3>Vakken</h3><span>Onderwerpen en kleuren</span></div><button class="primary-button compact-button" data-action="new-subject">${icon('plus',15)} Vak</button></div><div class="admin-list">${data.subjects.map((subject) => `<article class="admin-list-row"><span class="list-color" style="background:${esc(subject.color)}"></span><div class="admin-list-main"><strong>${esc(subject.name)}</strong><span>${esc(subject.short)} · ${esc(subject.icon)}</span></div><div class="row-actions"><button title="Bewerken" data-action="edit-subject" data-id="${esc(subject.id)}">${icon('edit',16)}</button><button title="Verwijderen" data-action="delete-subject" data-id="${esc(subject.id)}">${icon('trash',16)}</button></div></article>`).join('')}</div>`;
  }
  if (adminTab === 'homework') {
    return `<div class="admin-section-head"><div><h3>Huiswerk</h3><span>Opdrachten en afvinken</span></div><button class="primary-button compact-button" data-action="new-homework">${icon('plus',15)} Opdracht</button></div>
      <div class="admin-list">${data.homework.map((item) => `<article class="admin-list-row"><span class="list-icon">${icon('graduation',21)}</span><div class="admin-list-main"><strong>${esc(item.description || item.title)}</strong><span>${esc(subjectById(item.subjectId)?.name || 'Geen vak')} · ${esc(item.date)} · ${item.done ? 'Afgerond' : 'Open'}</span></div><div class="row-actions"><button title="Bewerken" data-action="edit-homework" data-id="${esc(item.id)}">${icon('edit',16)}</button><button title="Verwijderen" data-action="delete-homework" data-id="${esc(item.id)}">${icon('trash',16)}</button></div></article>`).join('') || '<div class="admin-empty">Nog geen opdrachten.</div>'}</div>
      <section class="admin-card"><h3>Dagtaak toevoegen</h3><form data-form="task"><div class="field-grid two"><label class="field-label">Datum<input type="date" name="date" value="${selectedDate}" required></label><label class="field-label">Taak<input name="title" placeholder="Omschrijving" required></label></div><label class="check-field"><input type="checkbox" name="done"> Al voltooid</label><button class="secondary-button" type="submit">${icon('plus')} Dagtaak opslaan</button></form></section>
      ${data.tasks.length ? `<section class="admin-card"><h3>Dagelijkse taken</h3>${data.tasks.map((task) => `<div class="admin-simple-row"><span>${esc(task.date)} · ${esc(task.title)}</span><button data-action="delete-task" data-id="${esc(task.id)}">${icon('trash')}</button></div>`).join('')}</section>` : ''}`;
  }
  if (adminTab === 'notices') {
    return `<div class="admin-section-head"><div><h3>Meldingen</h3><span>Aankondigingen en waarschuwingen</span></div><button class="primary-button compact-button" data-action="new-notice">${icon('plus',15)} Melding</button></div><div class="admin-list">${data.notices.map((notice) => `<article class="admin-list-row"><span class="notice-swatch ${esc(notice.tone)}"></span><div class="admin-list-main"><strong>${esc(notice.text)}</strong><span>${esc(notice.date)} · ${esc(notice.tone)}</span></div><div class="row-actions"><button title="Bewerken" data-action="edit-notice" data-id="${esc(notice.id)}">${icon('edit',16)}</button><button title="Verwijderen" data-action="delete-notice" data-id="${esc(notice.id)}">${icon('trash',16)}</button></div></article>`).join('') || '<div class="admin-empty">Nog geen meldingen.</div>'}</div>`;
  }
  const isOff = data.daysOff.includes(selectedDate);
  return `<section class="admin-card"><h3>Dag beheren</h3><label class="field-label">Geselecteerde datum<input type="date" value="${selectedDate}" data-action="admin-selected-date"></label><p class="admin-muted">${data.lessons.filter((item) => item.date === selectedDate).length} lessen op ${esc(formatDateLong(selectedDate))}.</p><div class="button-stack"><button class="secondary-button" data-action="toggle-day-off">${icon('calendar')} ${isOff ? 'Lesvrije dag opheffen' : 'Markeer als lesvrije dag'}</button><button class="danger-button" data-action="clear-day">${icon('trash')} Alle lessen van deze dag verwijderen</button></div></section>
    <section class="admin-card"><h3>Dag kopiëren</h3><form data-form="copy-day"><div class="field-grid two"><label class="field-label">Van<input type="date" value="${selectedDate}" readonly></label><label class="field-label">Naar<input type="date" name="target" value="${selectedDate}" required></label></div><button class="secondary-button" type="submit">${icon('copy')} Lessen kopiëren</button></form></section>
    <section class="admin-card"><h3>Roostersjablonen</h3><form data-form="template"><label class="field-label">Naam sjabloon<input name="name" placeholder="Bijvoorbeeld: Maandag" required></label><button class="secondary-button" type="submit">${icon('save')} Huidige dag opslaan als sjabloon</button></form>
      ${data.templates.map((template) => `<div class="template-row"><span>${icon('folder',17)} <strong>${esc(template.name)}</strong><small>${template.lessons.length} lessen</small></span><form data-form="apply-template"><input type="hidden" name="id" value="${esc(template.id)}"><label class="field-label">Toepassen op<input name="date" type="date" value="${selectedDate}" required></label><div class="template-actions"><button type="submit">Toepassen</button><button type="button" data-action="delete-template" data-id="${esc(template.id)}">${icon('trash')}</button></div></form></div>`).join('') || '<p class="admin-muted">Nog geen sjablonen opgeslagen.</p>'}
    </section>`;
}

function subjectOptions(selected) {
  return data.subjects.map((subject) => `<option value="${esc(subject.id)}" ${subject.id === selected ? 'selected' : ''}>${esc(subject.name)}</option>`).join('');
}
function renderEditor() {
  if (editor.kind === 'lesson') return renderLessonEditor(editor.item);
  if (editor.kind === 'subject') return renderSubjectEditor(editor.item);
  if (editor.kind === 'homework') return renderHomeworkEditor(editor.item);
  if (editor.kind === 'notice') return renderNoticeEditor(editor.item);
  return '';
}
function renderLessonEditor(item) {
  const editing = Boolean(item.id);
  const repeatDays = item.repeatDays || [1, 2, 3, 4, 5];
  return `<div class="editor-backdrop" data-action="close-editor"><section class="editor-modal" data-stop-click="true"><header class="editor-header"><div><span class="admin-kicker">Les bewerken</span><h3>${editing ? 'Les aanpassen' : 'Nieuwe les'}</h3></div><button class="close-button" data-action="close-editor">${icon('close')}</button></header>
    <form data-form="lesson" class="editor-scroll"><input type="hidden" name="id" value="${esc(item.id || '')}"><div class="field-grid two">
      <label class="field-label span-two">Naam van de les<input name="title" value="${esc(item.title)}" placeholder="Bijvoorbeeld: Nederlandse taal" required></label>
      <label class="field-label">Vak<select name="subjectId">${subjectOptions(item.subjectId)}</select></label>
      <label class="field-label">Type<input name="type" value="${esc(item.type || '')}" placeholder="Les, toets…"></label>
      <label class="field-label">Datum<input name="date" type="date" value="${esc(item.date)}" required></label>
      <label class="field-label">Lokaal<input name="room" value="${esc(item.room || '')}" placeholder="h114"></label>
      <label class="field-label">Begintijd<input name="start" type="time" value="${esc(item.start || '08:00')}" required></label>
      <label class="field-label">Eindtijd<input name="end" type="time" value="${esc(item.end || '09:00')}" required></label>
      <label class="field-label">Docent<input name="teacher" value="${esc(item.teacher || '')}"></label>
      <label class="field-label">Groep<input name="group" value="${esc(item.group || '')}"></label>
      <label class="field-label">Kaartkleur<input name="color" type="color" value="${esc(item.color || '#1c344c')}"></label>
      <label class="field-label span-two">Extra informatie<input name="info" value="${esc(item.info || '')}"></label>
      <label class="field-label span-two">Notities<textarea name="notes" rows="2">${esc(item.notes || '')}</textarea></label>
    </div>
    ${editing && item.seriesId ? `<label class="field-label">Wijziging toepassen<select name="seriesScope"><option value="one">Alleen deze les</option><option value="series">De hele herhalingsreeks</option></select></label>` : ''}
    ${!editing ? `<div class="repeat-box"><label class="check-field"><input type="checkbox" name="repeatWeekly"> Herhaal wekelijks</label><div class="repeat-options"><div class="weekday-checks">${[['1','Ma'],['2','Di'],['3','Wo'],['4','Do'],['5','Vr'],['6','Za'],['0','Zo']].map(([value, label]) => `<label><input type="checkbox" name="repeatDays" value="${value}" ${repeatDays.includes(Number(value)) ? 'checked' : ''}>${label}</label>`).join('')}</div><label class="field-label">Herhalen tot<input type="date" name="repeatUntil" value="${esc(item.repeatUntil || item.date)}" min="${esc(item.date)}"></label></div></div>` : ''}
    <div class="editor-footer"><button type="button" class="secondary-button" data-action="close-editor">Annuleren</button><button type="submit" class="primary-button">${icon('save')} Opslaan</button></div></form></section></div>`;
}
function renderSubjectEditor(item) {
  return `<div class="editor-backdrop" data-action="close-editor"><section class="editor-modal short-editor" data-stop-click="true"><header class="editor-header"><div><span class="admin-kicker">Vak</span><h3>${item.id ? 'Vak bewerken' : 'Nieuw vak'}</h3></div><button class="close-button" data-action="close-editor">${icon('close')}</button></header><form data-form="subject" class="editor-scroll"><input type="hidden" name="id" value="${esc(item.id || '')}"><div class="field-grid two"><label class="field-label span-two">Naam<input name="name" value="${esc(item.name || '')}" required></label><label class="field-label">Afkorting<input name="short" value="${esc(item.short || '')}"></label><label class="field-label">Icoon<input name="icon" value="${esc(item.icon || '▣')}"></label><label class="field-label">Kleur<input name="color" type="color" value="${esc(item.color || '#a8d5ff')}"></label><label class="field-label span-two">Omschrijving<textarea name="description" rows="2">${esc(item.description || '')}</textarea></label></div><div class="editor-footer"><button type="button" class="secondary-button" data-action="close-editor">Annuleren</button><button type="submit" class="primary-button">${icon('save')} Opslaan</button></div></form></section></div>`;
}
function renderHomeworkEditor(item) {
  return `<div class="editor-backdrop" data-action="close-editor"><section class="editor-modal short-editor" data-stop-click="true"><header class="editor-header"><div><span class="admin-kicker">Huiswerk</span><h3>${item.id ? 'Opdracht bewerken' : 'Nieuwe opdracht'}</h3></div><button class="close-button" data-action="close-editor">${icon('close')}</button></header><form data-form="homework" class="editor-scroll"><input type="hidden" name="id" value="${esc(item.id || '')}"><div class="field-grid two"><label class="field-label">Vak<select name="subjectId">${subjectOptions(item.subjectId)}</select></label><label class="field-label">Datum<input type="date" name="date" value="${esc(item.date)}" required></label><label class="field-label span-two">Les koppelen<select name="lessonId"><option value="">Geen specifieke les</option>${data.lessons.map((lesson) => `<option value="${esc(lesson.id)}" ${lesson.id === item.lessonId ? 'selected' : ''}>${esc(lesson.date)} · ${esc(lesson.start)} · ${esc(subjectById(lesson.subjectId)?.name || lesson.title)}</option>`).join('')}</select></label><label class="field-label span-two">Titel<input name="title" value="${esc(item.title || 'Huiswerk')}"></label><label class="field-label span-two">Omschrijving<textarea name="description" rows="3">${esc(item.description || '')}</textarea></label></div><label class="check-field"><input type="checkbox" name="done" ${item.done ? 'checked' : ''}> Afgevinkt</label><div class="editor-footer"><button type="button" class="secondary-button" data-action="close-editor">Annuleren</button><button type="submit" class="primary-button">${icon('save')} Opslaan</button></div></form></section></div>`;
}
function renderNoticeEditor(item) {
  return `<div class="editor-backdrop" data-action="close-editor"><section class="editor-modal short-editor" data-stop-click="true"><header class="editor-header"><div><span class="admin-kicker">Melding</span><h3>${item.id ? 'Melding bewerken' : 'Nieuwe melding'}</h3></div><button class="close-button" data-action="close-editor">${icon('close')}</button></header><form data-form="notice" class="editor-scroll"><input type="hidden" name="id" value="${esc(item.id || '')}"><div class="field-grid two"><label class="field-label span-two">Tekst<input name="text" value="${esc(item.text || '')}" required></label><label class="field-label">Datum<input name="date" type="date" value="${esc(item.date)}" required></label><label class="field-label">Kleur<select name="tone"><option value="orange" ${item.tone === 'orange' ? 'selected' : ''}>Oranje</option><option value="red" ${item.tone === 'red' ? 'selected' : ''}>Rood</option><option value="blue" ${item.tone === 'blue' ? 'selected' : ''}>Blauw</option></select></label></div><div class="editor-footer"><button type="button" class="secondary-button" data-action="close-editor">Annuleren</button><button type="submit" class="primary-button">${icon('save')} Opslaan</button></div></form></section></div>`;
}

function startEditor(kind, item = null) {
  const date = selectedDate;
  if (kind === 'lesson') editor = { kind, item: item ? { ...item } : {
    date, start:'08:00', end:'09:00', title:'', subjectId:data.subjects[0]?.id || '', room:'', teacher:'', group:'', color:'#1c344c', info:'', notes:'', type:'', repeatUntil:date, repeatDays:[1,2,3,4,5], id:'',
  } };
  if (kind === 'subject') editor = { kind, item: item ? { ...item } : { id:'', name:'', short:'', icon:'▣', color:'#a8d5ff', description:'' } };
  if (kind === 'homework') editor = { kind, item: item ? { ...item } : { id:'', subjectId:data.subjects[0]?.id || '', date, title:'Huiswerk', description:'', done:false } };
  if (kind === 'notice') editor = { kind, item: item ? { ...item } : { id:'', date, text:'', tone:'orange' } };
  render();
}

function handleClick(event) {
  const target = event.target instanceof Element ? event.target : null;
  if (!target) return;
  const actionElement = target.closest('[data-action]');
  if (!actionElement) return;
  const action = actionElement.dataset.action;
  if (['close-sheet','close-menu','close-editor','close-message'].includes(action) && actionElement.matches('.sheet-backdrop,.drawer-backdrop,.editor-backdrop') && target.closest('[data-stop-click]')) return;
  const id = actionElement.dataset.id;

  switch (action) {
    case 'month-tap': handleMonthTap(); break;
    case 'open-menu': sidebarOpen = true; render(); break;
    case 'close-menu': sidebarOpen = false; render(); break;
    case 'backup-export': exportBackup(); break;
    case 'date-picker': {
      const input = document.getElementById('top-date-picker');
      if (input) { if (input.showPicker) input.showPicker(); else input.click(); }
      break;
    }
    case 'today': setDate(TODAY); break;
    case 'prev-day': setDate(toISO(addDays(currentDate(), -1))); break;
    case 'next-day': setDate(toISO(addDays(currentDate(), 1))); break;
    case 'select-date': setDate(actionElement.dataset.date); break;
    case 'toggle-tasks': taskExpanded = !taskExpanded; render(); break;
    case 'toggle-notice': noticeExpanded = !noticeExpanded; render(); break;
    case 'tab':
      activeTab = actionElement.dataset.tab;
      subjectViewId = null; materialsLessonId = null; messageDetailId = null; sidebarOpen = false;
      render(); break;
    case 'open-lesson': detailLessonId = id; render(); break;
    case 'close-sheet': detailLessonId = null; render(); break;
    case 'sheet-open-subject': {
      const lesson = lessonById(detailLessonId);
      if (lesson) { subjectViewId = lesson.subjectId; detailLessonId = null; render(); }
      break;
    }
    case 'open-subject': subjectViewId = id; activeTab = 'Rooster'; materialsLessonId = null; render(); break;
    case 'back-subpage': subjectViewId = null; materialsLessonId = null; render(); break;
    case 'open-materials': materialsLessonId = detailLessonId; detailLessonId = null; render(); break;
    case 'open-message': {
      const message = data.messages.find((item) => item.id === id);
      if (!message) break;
      if (message.unread) commit((current) => ({ ...current, messages: current.messages.map((item) => item.id === id ? { ...item, unread:false } : item) }));
      messageDetailId = id; render(); break;
    }
    case 'close-message': messageDetailId = null; render(); break;
    case 'admin-tab': adminTab = actionElement.dataset.tab; render(); break;
    case 'close-admin': adminOpen = false; editor = null; render(); break;
    case 'new-lesson': startEditor('lesson'); break;
    case 'edit-lesson': { const item = lessonById(id); if (item) startEditor('lesson', item); break; }
    case 'duplicate-lesson': {
      const item = lessonById(id);
      if (item) commit((current) => ({ ...current, lessons:[...current.lessons, { ...item, id:uid(), seriesId:undefined }] }));
      break;
    }
    case 'delete-lesson': deleteLesson(id); break;
    case 'new-subject': startEditor('subject'); break;
    case 'edit-subject': { const item = subjectById(id); if (item) startEditor('subject', item); break; }
    case 'delete-subject': deleteSubject(id); break;
    case 'new-homework': startEditor('homework'); break;
    case 'edit-homework': { const item = data.homework.find((entry) => entry.id === id); if (item) startEditor('homework', item); break; }
    case 'delete-homework': deleteHomework(id); break;
    case 'new-notice': startEditor('notice'); break;
    case 'edit-notice': { const item = data.notices.find((entry) => entry.id === id); if (item) startEditor('notice', item); break; }
    case 'delete-notice': deleteNotice(id); break;
    case 'close-editor': editor = null; render(); break;
    case 'undo': undo(); break;
    case 'toggle-day-off': commit((current) => ({ ...current, daysOff: current.daysOff.includes(selectedDate) ? current.daysOff.filter((date) => date !== selectedDate) : [...current.daysOff, selectedDate] })); break;
    case 'clear-day': clearDay(); break;
    case 'delete-task': commit((current) => ({ ...current, tasks: current.tasks.filter((item) => item.id !== id) })); break;
    case 'delete-template': commit((current) => ({ ...current, templates: current.templates.filter((item) => item.id !== id) })); break;
  }
}

function deleteLesson(id) {
  const item = lessonById(id);
  if (!item) return;
  if (item.seriesId) {
    const removeSeries = window.confirm('Deze les hoort bij een herhalingsreeks. Verwijder de HELE reeks?\n\nOK = hele reeks · Annuleren = alleen deze datum kiezen');
    if (removeSeries) commit((current) => ({ ...current, lessons: current.lessons.filter((lesson) => lesson.seriesId !== item.seriesId) }));
    else if (window.confirm('Alleen deze les op deze datum verwijderen?')) commit((current) => ({ ...current, lessons: current.lessons.filter((lesson) => lesson.id !== id) }));
  } else if (window.confirm(`Les “${item.title}” op ${formatDateLong(item.date)} verwijderen?`)) {
    commit((current) => ({ ...current, lessons: current.lessons.filter((lesson) => lesson.id !== id) }));
  }
}
function deleteSubject(id) {
  const subject = subjectById(id);
  if (!subject) return;
  const linked = data.lessons.some((item) => item.subjectId === id) || data.homework.some((item) => item.subjectId === id);
  const prompt = linked ? `Vak “${subject.name}” verwijderen? Gekoppelde lessen en opdrachten blijven bestaan, maar verliezen de vakverwijzing.` : `Vak “${subject.name}” verwijderen?`;
  if (window.confirm(prompt)) commit((current) => ({ ...current, subjects:current.subjects.filter((item) => item.id !== id) }));
}
function deleteHomework(id) {
  if (window.confirm('Deze huiswerkopdracht verwijderen?')) commit((current) => ({ ...current, homework:current.homework.filter((item) => item.id !== id) }));
}
function deleteNotice(id) {
  if (window.confirm('Deze mededeling verwijderen?')) commit((current) => ({ ...current, notices:current.notices.filter((item) => item.id !== id) }));
}
function clearDay() {
  const count = data.lessons.filter((item) => item.date === selectedDate).length;
  if (!count) { alert('Deze dag bevat geen lessen.'); return; }
  if (window.confirm(`Alle ${count} lessen van ${formatDateLong(selectedDate)} verwijderen?`)) commit((current) => ({ ...current, lessons:current.lessons.filter((item) => item.date !== selectedDate) }));
}

function handleChange(event) {
  const target = event.target;
  if (!(target instanceof HTMLElement)) return;
  if (target.id === 'top-date-picker' && target.value) { setDate(target.value); return; }
  if (target.matches('[data-action="admin-selected-date"]') && target.value) { selectedDate = target.value; render(); return; }
  if (target.matches('input[data-action="toggle-task"]')) {
    const id = target.dataset.id;
    const kind = target.dataset.kind;
    if (kind === 'task') commit((current) => ({ ...current, tasks: current.tasks.map((item) => item.id === id ? { ...item, done:target.checked } : item) }));
    if (kind === 'homework') commit((current) => ({ ...current, homework: current.homework.map((item) => item.id === id ? { ...item, done:target.checked } : item) }));
    return;
  }
  if (target.matches('input[data-action="backup-import"]')) {
    const file = target.files?.[0];
    if (file) importBackup(file);
  }
}

function formDataObject(form) {
  const formData = new FormData(form);
  return Object.fromEntries(formData.entries());
}
function handleSubmit(event) {
  const form = event.target;
  if (!(form instanceof HTMLFormElement) || !form.dataset.form) return;
  event.preventDefault();
  const kind = form.dataset.form;
  const fd = new FormData(form);
  if (kind === 'lesson') {
    const item = {
      title:String(fd.get('title') || '').trim(), subjectId:String(fd.get('subjectId') || ''), date:String(fd.get('date') || ''),
      start:String(fd.get('start') || '08:00'), end:String(fd.get('end') || '09:00'), room:String(fd.get('room') || ''),
      teacher:String(fd.get('teacher') || ''), group:String(fd.get('group') || ''), color:String(fd.get('color') || '#1c344c'),
      info:String(fd.get('info') || ''), notes:String(fd.get('notes') || ''), type:String(fd.get('type') || ''),
    };
    if (!item.title || !item.date) { alert('Vul een naam en datum in.'); return; }
    if (timeToMinutes(item.end) <= timeToMinutes(item.start)) { alert('De eindtijd moet na de begintijd liggen.'); return; }
    const id = String(fd.get('id') || '');
    if (id) {
      const original = lessonById(id);
      const scope = String(fd.get('seriesScope') || 'one');
      if (scope === 'series' && original?.seriesId) {
        const shiftDays = Math.round((fromISO(item.date) - fromISO(original.date)) / 86400000);
        commit((current) => ({ ...current, lessons:current.lessons.map((lesson) => lesson.seriesId === original.seriesId ? { ...lesson, ...item, id:lesson.id, date:toISO(addDays(fromISO(lesson.date), shiftDays)), seriesId:original.seriesId } : lesson) }));
      } else commit((current) => ({ ...current, lessons:current.lessons.map((lesson) => lesson.id === id ? { ...lesson, ...item, id, seriesId:undefined } : lesson) }));
    } else if (fd.get('repeatWeekly') === 'on') {
      const repeatDays = fd.getAll('repeatDays').map(Number);
      if (!repeatDays.length) { alert('Kies minstens één herhalingsdag.'); return; }
      const untilText = String(fd.get('repeatUntil') || item.date);
      if (untilText < item.date) { alert('De einddatum van de herhaling ligt vóór de startdatum.'); return; }
      const seriesId = uid();
      const occurrences = [];
      const cursor = fromISO(item.date);
      const until = fromISO(untilText);
      while (cursor <= until) {
        if (repeatDays.includes(cursor.getDay())) occurrences.push({ ...item, date:toISO(cursor), id:uid(), seriesId });
        cursor.setDate(cursor.getDate() + 1);
      }
      if (!occurrences.length) { alert('Er zijn geen lessen aangemaakt binnen deze herhaalperiode.'); return; }
      commit((current) => ({ ...current, lessons:[...current.lessons, ...occurrences] }));
    } else commit((current) => ({ ...current, lessons:[...current.lessons, { ...item, id:uid() }] }));
    editor = null; render(); return;
  }
  if (kind === 'subject') {
    const subject = { id:String(fd.get('id') || ''), name:String(fd.get('name') || '').trim(), short:String(fd.get('short') || ''), icon:String(fd.get('icon') || '▣'), color:String(fd.get('color') || '#a8d5ff'), description:String(fd.get('description') || '') };
    if (!subject.name) { alert('Vul een vaknaam in.'); return; }
    if (subject.id) {
      const previous = subjectById(subject.id);
      commit((current) => ({ ...current, subjects:current.subjects.map((item) => item.id === subject.id ? subject : item), lessons:current.lessons.map((lesson) => lesson.subjectId === subject.id && previous && lesson.title === previous.name ? { ...lesson, title:subject.name } : lesson) }));
    } else commit((current) => ({ ...current, subjects:[...current.subjects, { ...subject, id:uid() }] }));
    editor = null; render(); return;
  }
  if (kind === 'homework') {
    const item = { id:String(fd.get('id') || ''), subjectId:String(fd.get('subjectId') || ''), lessonId:String(fd.get('lessonId') || ''), date:String(fd.get('date') || ''), title:String(fd.get('title') || 'Huiswerk'), description:String(fd.get('description') || ''), done:fd.get('done') === 'on' };
    if (item.id) commit((current) => ({ ...current, homework:current.homework.map((entry) => entry.id === item.id ? item : entry) }));
    else commit((current) => ({ ...current, homework:[...current.homework, { ...item, id:uid() }] }));
    editor = null; render(); return;
  }
  if (kind === 'notice') {
    const item = { id:String(fd.get('id') || ''), date:String(fd.get('date') || ''), text:String(fd.get('text') || '').trim(), tone:String(fd.get('tone') || 'orange') };
    if (!item.text) { alert('Vul een mededeling in.'); return; }
    if (item.id) commit((current) => ({ ...current, notices:current.notices.map((entry) => entry.id === item.id ? item : entry) }));
    else commit((current) => ({ ...current, notices:[...current.notices, { ...item, id:uid() }] }));
    editor = null; render(); return;
  }
  if (kind === 'task') {
    const item = { id:uid(), date:String(fd.get('date') || selectedDate), title:String(fd.get('title') || '').trim(), done:fd.get('done') === 'on' };
    if (!item.title) return;
    commit((current) => ({ ...current, tasks:[...current.tasks, item] })); return;
  }
  if (kind === 'copy-day') {
    const target = String(fd.get('target') || '');
    const source = data.lessons.filter((lesson) => lesson.date === selectedDate);
    if (!source.length) { alert('Er zijn geen lessen op de gekozen brondag.'); return; }
    if (!target) return;
    const copies = source.map((lesson) => ({ ...lesson, id:uid(), date:target, seriesId:undefined }));
    commit((current) => ({ ...current, lessons:[...current.lessons, ...copies] })); return;
  }
  if (kind === 'template') {
    const name = String(fd.get('name') || '').trim();
    const source = data.lessons.filter((lesson) => lesson.date === selectedDate);
    if (!source.length) { alert('Er zijn geen lessen om als sjabloon op te slaan.'); return; }
    if (!name) { alert('Geef het sjabloon een naam.'); return; }
    const template = { id:uid(), name, lessons:source.map(({ id:_id, date:_date, seriesId:_seriesId, ...fields }) => fields) };
    commit((current) => ({ ...current, templates:[...current.templates, template] })); return;
  }
  if (kind === 'apply-template') {
    const template = data.templates.find((item) => item.id === String(fd.get('id') || ''));
    const date = String(fd.get('date') || '');
    if (!template || !date) return;
    const copies = template.lessons.map((lesson) => ({ ...lesson, id:uid(), date, seriesId:undefined }));
    commit((current) => ({ ...current, lessons:[...current.lessons, ...copies] })); return;
  }
}

function exportBackup() {
  const filename = `rooster-backup-${TODAY}.json`;
  const json = JSON.stringify(data, null, 2);
  if (window.RoosterNative && typeof window.RoosterNative.saveBackup === 'function') {
    const bytes = new TextEncoder().encode(json);
    let binary = '';
    for (let offset = 0; offset < bytes.length; offset += 0x8000) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
    }
    window.RoosterNative.saveBackup(filename, btoa(binary));
    return;
  }
  const blob = new Blob([json], { type:'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url; link.download = filename; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
async function importBackup(file) {
  try {
    const imported = JSON.parse(await file.text());
    if (!imported || !Array.isArray(imported.lessons) || !Array.isArray(imported.subjects)) throw new Error('Ongeldig back-upbestand');
    const replacement = {
      lessons:imported.lessons || [], subjects:imported.subjects || [], homework:imported.homework || [],
      tasks:imported.tasks || [], notices:imported.notices || [], templates:imported.templates || [],
      messages:imported.messages || [], daysOff:imported.daysOff || [],
    };
    commit(() => replacement);
    alert('Back-up hersteld.');
  } catch (error) {
    console.error(error);
    alert('Dit back-upbestand kon niet worden hersteld. Controleer het JSON-bestand.');
  }
}

// Native Android back button closes the top-most open panel first.
window.roosterHandleAndroidBack = () => {
  if (editor) { editor = null; render(); return true; }
  if (adminOpen) { adminOpen = false; render(); return true; }
  if (sidebarOpen) { sidebarOpen = false; render(); return true; }
  if (detailLessonId) { detailLessonId = null; render(); return true; }
  if (materialsLessonId) { materialsLessonId = null; render(); return true; }
  if (subjectViewId) { subjectViewId = null; materialsLessonId = null; render(); return true; }
  if (messageDetailId) { messageDetailId = null; render(); return true; }
  return false;
};

root.addEventListener('click', handleClick);
root.addEventListener('change', handleChange);
root.addEventListener('submit', handleSubmit);

// Start with the recording's current weekday and keep changes across reloads.
render();
loadData().then((stored) => {
  if (stored && Array.isArray(stored.lessons) && Array.isArray(stored.subjects)) {
    data = {
      lessons:stored.lessons || [], subjects:stored.subjects || [], homework:stored.homework || [],
      tasks:stored.tasks || [], notices:stored.notices || [], templates:stored.templates || [],
      messages:stored.messages || [], daysOff:stored.daysOff || [],
    };
  } else saveData(data).catch((error) => console.warn(error));
  loaded = true;
  render();
}).catch((error) => { console.warn(error); loaded = true; render(); });
