const DB_NAME = 'rooster-recreation-db';
const STORE_NAME = 'app-state';
const KEY = 'primary';
const FALLBACK_KEY = 'rooster-recreation-data-v1';
let memoryFallback = null;
function openDb() {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) return reject(new Error('IndexedDB unavailable'));
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(STORE_NAME)) request.result.createObjectStore(STORE_NAME);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Could not open IndexedDB'));
  });
}
export async function loadData() {
  try {
    const db = await openDb();
    const value = await new Promise((resolve, reject) => {
      const request = db.transaction(STORE_NAME, 'readonly').objectStore(STORE_NAME).get(KEY);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
    db.close();
    if (value) return value;
  } catch (error) { console.warn('IndexedDB unavailable, trying localStorage.', error); }
  try { const raw = localStorage.getItem(FALLBACK_KEY); return raw ? JSON.parse(raw) : memoryFallback ? JSON.parse(memoryFallback) : null; }
  catch (error) { console.warn('Could not read local data.', error); return memoryFallback ? JSON.parse(memoryFallback) : null; }
}
export async function saveData(value) {
  try {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(value, KEY);
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error('Save aborted'));
    });
    db.close();
    return;
  } catch (error) { console.warn('IndexedDB save failed, falling back to localStorage.', error); }
  const serialized = JSON.stringify(value);
  memoryFallback = serialized;
  try { localStorage.setItem(FALLBACK_KEY, serialized); } catch (error) { console.warn('No persistent browser storage is available in this context.', error); }
}
